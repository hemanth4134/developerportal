// index.js for AWS Lambda
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  try {
    const data = JSON.parse(event.body);

    const item = {
      requestId: uuidv4(),
      timestamp: new Date().toISOString(),
      employee: data.employee,
      project: data.project
    };

    await dynamo.put({
      TableName: 'DeveloperPortalRequests',
      Item: item
    }).promise();

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ message: 'Success', requestId: item.requestId })
    };
  } catch (err) {
    console.error('Error:', err);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ message: 'Error storing data', error: err.message })
    };
  }
};
